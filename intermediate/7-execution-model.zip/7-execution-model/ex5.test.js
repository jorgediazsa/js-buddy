'use strict';

const { maxSafeRecursionDepth } = require('./ex5');

function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

let maxSeen = -1;
let depth;
try {
  depth = maxSafeRecursionDepth((d) => {
    if (d > maxSeen) maxSeen = d;
  });
} catch (err) {
  assert(false, 'maxSafeRecursionDepth should not throw: ' + err.name);
}

assert(Number.isInteger(depth), 'depth should be integer');
assert(depth > 0, 'depth should be positive');
assert(depth < 1e7, 'depth should be reasonable');
assert(maxSeen >= 0, 'fn should be invoked');
assert(depth <= maxSeen + 1, 'depth should align with observed max');

function canRecurse(n) {
  try {
    (function rec(k) {
      if (k === 0) return;
      rec(k - 1);
    })(n);
    return true;
  } catch (err) {
    if (err instanceof RangeError) return false;
    throw err;
  }
}

const safeDepth = Math.max(1, Math.floor(depth * 0.9));
assert(canRecurse(safeDepth) === true, 'estimate should be safely under max');

console.log('ex5 tests passed');
