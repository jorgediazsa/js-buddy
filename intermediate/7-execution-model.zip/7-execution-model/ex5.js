'use strict';

/*
Problem:
Implement maxSafeRecursionDepth(fn) to estimate the maximum call stack depth
before RangeError.

Rules:
- fn(depth) must be invoked in each recursive frame.
- Use bounded search; do not crash the process.
- Return a positive integer estimate.
*/

function maxSafeRecursionDepth(fn) {
  // TODO: probe stack depth safely and return a positive integer.
  fn(0);
  return 0;
}

module.exports = { maxSafeRecursionDepth };
