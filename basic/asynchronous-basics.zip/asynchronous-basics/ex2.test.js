'use strict';

const { runCallbackSafely } = require('./ex2');

function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

// Sync success
runCallbackSafely(() => 42, (err, value) => {
  assert(err == null, 'err should be null on success');
  assert(value === 42, 'value should be 42');

  // Sync throw
  runCallbackSafely(() => { throw new Error('boom'); }, (err2, value2) => {
    assert(err2 instanceof Error, 'err should be Error');
    assert(value2 === undefined, 'value should be undefined on error');

    // Async throw should not be caught
    let asyncCaught = false;
    process.once('uncaughtException', () => { asyncCaught = true; });

    runCallbackSafely(() => {
      setTimeout(() => { throw new Error('async'); }, 0);
      return 'ok';
    }, (err3, value3) => {
      assert(err3 == null, 'async error should not be caught');
      assert(value3 === 'ok', 'value should be ok');

      setTimeout(() => {
        assert(asyncCaught === true, 'async error should escape try/catch');
        console.log('ex2 tests passed');
      }, 10);
    });
  });
});
